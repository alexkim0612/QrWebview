package org.techtown.qrwebview;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MenuActivity extends Activity {

    ImageView btn_exit, btn_fem;
    RecyclerView recyclerView;
    RecyclerView.Adapter adapter;
    RecyclerView.LayoutManager layoutManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select);

        recyclerView = findViewById(R.id.recycler_view);

        // 리사이클러뷰의 notify()처럼 데이터가 변했을 때 성능을 높일 때 사용한다.
        recyclerView.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        String[] textSet =  {"Boiler Feed Pump - Pump \nB9:40:7F:30:F1","Boiler Feed Pump - Turbine \n59:B0:7F:E6:45","Boiler Feed Pump - Motor \nB21:B3:E5:05:01","Boost-Up Fan - Fan \n21:C3:04:01:E2"};
        int[] imgSet = {R.drawable.wifi, R.drawable.wifi, R.drawable.wifi, R.drawable.wifi};
        int[] imgSet2 = {R.drawable.btn, R.drawable.btn, R.drawable.btn, R.drawable.btn};

        // 어댑터 할당, 어댑터는 기본 어댑터를 확장한 커스텀 어댑터를 사용할 것이다.
        adapter = new MyAdapter(textSet, imgSet, imgSet2);
        recyclerView.setAdapter(adapter);
            btn_exit = (ImageView) findViewById(R.id.btn_exit);
        btn_exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MenuActivity.this);
                builder.setMessage("정말로 종료하시겠습니까?");
                builder.setTitle("경고")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener(){
                            @Override
                            public void onClick(DialogInterface dialog, int i){
                                moveTaskToBack(true);
                                finishAndRemoveTask(); //액티비티만 죽이고 백그라운드 프로세스는 계속 실행
                                //android.os.Process.killProcess(android.os.Process.myPic());
                                // 백그라운드 프로세스 까지 종료

                          }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener(){
                            @Override
                            public void onClick(DialogInterface dialog, int i){
                                dialog.cancel();
                            }
                        });
                AlertDialog alert = builder.create();
                alert.setTitle("경고");
                alert.show();
            }
        });
        btn_fem = (ImageView)findViewById(R.id.fem_btn);
        btn_fem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), MainActivity.class);
                startActivity(intent);
            }
        });


    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
        finishAndRemoveTask();
    }
}
